# Ionic 3 + Angular 5 + ngx-translate 9

Simple demo project showing how to add translations to your ionic + angular app.

**Ionic 3 currently works with Angular v5. This means that you also have to use ngx-translate 9.x**
# teste0101
